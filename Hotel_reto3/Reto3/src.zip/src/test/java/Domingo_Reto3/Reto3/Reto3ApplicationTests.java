package Domingo_Reto3.Reto3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
